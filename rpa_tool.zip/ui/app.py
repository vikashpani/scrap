
import streamlit as st
import subprocess

st.title("RPA Automation Tool")

if st.button("Start Recorder"):
    subprocess.Popen(["python", "recorder/record_actions.py"])

if st.button("Play Automation Script"):
    subprocess.Popen(["python", "player/play_script.py"])

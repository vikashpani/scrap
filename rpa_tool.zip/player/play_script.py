
from pywinauto import Application
import json
import time

with open("recorded_user_actions.json", "r") as f:
    actions = json.load(f)

app = Application(backend="uia").start(r"C:\Path\to\YourApp.exe")
dlg = app.top_window()

for action in actions:
    ctrl_info = action["control"]
    try:
        ctrl = dlg.child_window(title=ctrl_info['name'], control_type=ctrl_info['control_type'])
        ctrl.wait('ready', timeout=5)
        
        if action["event"] == "mouse_click":
            ctrl.click_input()
        elif action["event"] == "key_press":
            if ctrl_info['control_type'] == "Edit":
                ctrl.type_keys(action["key"], with_spaces=True, set_foreground=True)
        
        time.sleep(1)

    except Exception as e:
        print(f"Error with action on {ctrl_info['name']}: {e}")

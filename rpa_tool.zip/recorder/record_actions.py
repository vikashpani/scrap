
import mouse
import keyboard
import json
import time
from pywinauto import Desktop

recorded_actions = []

print("Recording actions... Press ESC to stop.")

def get_focused_control():
    try:
        focused = Desktop(backend="uia").get_active()
        info = focused.element_info
        return {
            "name": info.name,
            "control_type": info.control_type,
            "automation_id": info.automation_id,
            "rectangle": str(info.rectangle)
        }
    except:
        return None

def on_click(event):
    ctrl = get_focused_control()
    if ctrl:
        recorded_actions.append({
            "event": "mouse_click",
            "button": event.button,
            "time": time.time(),
            "control": ctrl
        })
        print(f"Clicked on {ctrl['name']}")

def on_key(event):
    if event.name == 'esc':
        print("Recording stopped.")
        mouse.unhook_all()
        keyboard.unhook_all()
        with open("recorded_user_actions.json", "w") as f:
            json.dump(recorded_actions, f, indent=4)
        exit()
    else:
        ctrl = get_focused_control()
        if ctrl:
            recorded_actions.append({
                "event": "key_press",
                "key": event.name,
                "time": time.time(),
                "control": ctrl
            })
            print(f"Typed '{event.name}' in {ctrl['name']}")

mouse.hook(on_click)
keyboard.hook(on_key)
keyboard.wait('esc')
